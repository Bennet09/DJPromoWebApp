﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using DJPromoWebApp.Data;
using DJPromoWebApp.Models;

namespace DJPromoWebApp.Pages.DJs
{
    public class DJModel : PageModel
    {
        private readonly DJPromoWebApp.Data.DJContext _context;

        public DJModel(DJPromoWebApp.Data.DJContext context)
        {
            _context = context;
        }

        public IList<DJ> DJ { get;set; } = default!;

        public async Task OnGetAsync()
        {
            if (_context.DJ != null)
            {
                DJ = await _context.DJ.ToListAsync();
            }
        }
    }
}
